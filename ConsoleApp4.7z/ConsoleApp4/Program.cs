﻿using System;
using System.Linq;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Threading;

namespace ConsoleApp4
{
    public class MainProgram
    {
        public static void Main()
        {
            while (true)
            {
                string currenttrack = Spotify.CurrentTrack();
                TxtWorker.CfgReader();
                Console.WriteLine(currenttrack);
                Thread.Sleep(5000);
            }
        }
    }
    public class Spotify
    {

        public static string CurrentTrack()
        {
            var proc = Process.GetProcessesByName("Spotify").FirstOrDefault(p => !string.IsNullOrWhiteSpace(p.MainWindowTitle));

            if (proc == null)
            {
                return "Spotify is not running!";
            }

            else if (string.Equals(proc.MainWindowTitle, "Spotify", StringComparison.InvariantCultureIgnoreCase))
            {
                return "Paused";
            }
            else
            {
                return proc.MainWindowTitle;
            }
        }
    }


    public class TxtWorker
    {
        static public string ToWrite = $"bind \"kp_5\" \"say Now Playing: {Spotify.CurrentTrack()}\"";
        static string WritePath = @"C:\Program Files (x86)\Steam\userdata\73467495\730\local\cfg\audio.cfg";
        static StreamWriter Wcfg = new StreamWriter(WritePath, false, System.Text.Encoding.Default);
        static public void CfgReader()
        {
            Wcfg.WriteLine(ToWrite);
            Wcfg.Close();
        }
    }
}
    

